

#define WE 48
#define OE 49
#define CE 50
#define CE2 51

#define A0 22
#define A1 23
#define A2 24
#define AB3 25
#define AB4 26
#define A5 27
#define A6 28
#define A7 29
#define A8 30
#define A9 31
#define A10 32
#define A11 33
#define A12 34
#define A13 35
#define A14 36
#define A15 37
#define A16 38

#define D0 39
#define D1 40
#define D2 41
#define D3 42
#define D4 43
#define D5 44
#define D6 45
#define D7 46
