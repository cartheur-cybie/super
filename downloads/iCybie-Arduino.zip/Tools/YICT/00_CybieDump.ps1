# -- Variables and Constants --
$chunk = 4096 # Bytes to Read at a time
$bytesRead = 0 # Counter of Bytes Read / Written
$percent = 0
$fileSize = 131072
$filePath = "$PSScriptRoot" + "\"
$cartDump = New-Object Byte[] $fileSize
$cartROM = New-Object Byte[] $fileSize
$portsAvailable = [System.IO.Ports.SerialPort]::getportnames()


# -- Gather User Input --
# Cartridge Side Select
do {
	Clear-Host
	$cartSide = Read-Host -Prompt "Please Select a Cartridge Side ( 'A' or 'B' )"
	$cartSide = $cartSide.ToUpper()
	} while ($cartSide -ne "A" -and $cartSide -ne "B")
#Read or Write
do {
	Clear-Host
	Write-Host "Write to Cartridge from File"
	Write-Host "           - OR -           "
	Write-Host "Read from Cartridge to File?"
	$cartAction = Read-Host -Prompt "( Write 'W' or Read 'R' )"
	$cartAction = $cartAction.ToUpper()
	} while ($cartAction -ne "W" -and $cartAction -ne "R")
#Filename Select
Clear-Host
Write-Host "Current Working Folder:" $filePath
$filePath += Read-Host -Prompt "Filename for ROM?"
#Verify Write?
Clear-Host
if ($cartAction -eq "W"){
	do {
		Clear-Host
		Write-Host "Verify after Writing?"
		$verifyCart = Read-Host -Prompt "( 'Y' or 'N' )"
		$verifyCart = $verifyCart.ToUpper()
		} while ($verifyCart -ne "Y" -and $verifyCart -ne "N")
	}
#Select COM Port
do {
	Clear-Host
	$portName = "COM"
	Write-Host "Select a COM port for Programmer"
	Write-Host "COM Ports Available:"
	Write-Host $portsAvailable
	$portName += Read-Host -Prompt "Enter Port Number"
	} while ($portsAvailable -notcontains $portName)


# -- Connect to Programmer -- 
#Configure Serial Session
Clear-Host
Write-Host "Opening Serial Port..."
$port = new-Object System.IO.Ports.SerialPort $portName,57600,None,8,one
$port.Encoding = [System.Text.Encoding]::ASCII
$port.ReadBufferSize = $chunk * 2
$port.WriteBufferSize = $chunk * 2
try {
    $port.Open()
    Write-Host "COM Port is Open - Ready."
}
catch {
    Write-Host "COM Port is Unavailable"
	Exit
}
Start-Sleep -Seconds 2
# Select Cartridge Side
Write-Host "Selecting Cartridge Side..."
$port.DiscardInBuffer() # Clear garbage data
switch ($cartSide){
 A { $port.Write([char]65) }
 B { $port.Write([char]66) }
}
Start-Sleep -Seconds 1
Write-Host $port.ReadExisting()


# -- Start Write to Cartridge --
if ($cartAction -eq "W") {
	# Run Test Write on Cartridge
	Write-Host "Testing Cartridge..."
	$port.DiscardInBuffer() # Clear garbage data
	$port.Write([char]89) # Send Test-Write Command
	Start-Sleep -Seconds 2
	$testCart = $port.ReadExisting() # Check for Test Data
	if ($testCart -eq "") {
		Write-Host "Error - No Response"
		$port.Close()
		Exit
	}
	Write-Host $testCart
	Write-Host "Test Write Done"	
	# Run Full Binary Write to Cartridge
	Write-Host "Starting ROM Write..."
	#Test if user-provided file exists
	Try{ 
        $cartROM = [System.IO.File]::ReadAllBytes($filePath)
    } 
    Catch{
        Write-Host "The path you entered is either invalid or the file does not exist."
		$port.Close()
		Exit 
    }
	$port.DiscardInBuffer() # Clear garbage data
	$port.Write([char]87) # Send Write Command
	Start-Sleep -Seconds 2 # Wait for programmer to be ready
	$bytesRead = 0 # Clear Read/Write Counter
	do {
		$port.Write($cartROM, $bytesRead, $chunk) # Write 4096 next bytes to serial buffer, offset by the number of bytes already sent.
		do {
			Start-Sleep -milliseconds 100 # Wait for serial buffer to be read by programmer.
			$bytesToRead=$port.BytesToWrite # Count the number of bytes read.
			} while ($bytesToRead) # Loop until all 4096 bytes are read.
		$bytesRead += $chunk # Count total bytes sent towards file progress.
		$percent = [int]($bytesRead / $fileSize * 100)
		Clear-Host
		Write-Host -NoNewline "Write Progress: $percent%"
	} while ($bytesRead -lt $filesize) # Repeat until number of bytes sent equals filesize.
	Start-Sleep -Seconds 1
	$port.ReadExisting() # Get confirmation message from programmer
	Write-Host "`nFlash Write Done."
	if ($verifyCart -eq "N"){
		Read-Host -Prompt "Press Enter to Quit"
		Exit # Quit if user is stupid
	} 
	else {
		Write-Host "Starting Verification..."
	}
}


# -- Start Read from Cartridge --
# Run Test Read on Cartridge
Write-Host "Testing Cartridge..."
$port.DiscardInBuffer() # Clear garbage data
$port.Write([char]88) # Send Test-Read Command
Start-Sleep -Seconds 2
$testCart = $port.ReadExisting() # Check for Test Data
	if ($testCart -eq "") {
		Write-Host "Error - No Response"
		$port.Close()
		Exit
	}
Write-Host $testCart
Write-Host "Test Read Done"
# Run Full Binary Read from Cartridge
Write-Host "Starting ROM Dump..."
Start-Sleep -Seconds 2
$port.DiscardInBuffer() # Clear garbage data
$port.Write([char]82) # Send Write Command
$bytesRead = 0 # Clear Read/Write Counter
do {
	do {
		Start-Sleep -milliseconds 100 # Wait for serial buffer to be written by programmer.
		$bytesToRead=$port.BytesToRead # Count the number of bytes available to read.
		} while ($bytesToRead -lt $chunk) # Loop until read 4096 bytes are available.
	$port.Read($cartDump, $bytesRead, $chunk) | Out-Null # Read 4096 next bytes from serial buffer, offset by the number of bytes already read.
	$bytesRead += $chunk # Count total bytes sent towards file progress.
	$percent = [int]($bytesRead / $fileSize * 100)
	Clear-Host
	Write-Host -NoNewline "Read Progress: $percent%"
} while ($bytesRead -lt $filesize -and $bytesToRead) # Repeat until number of bytes read equals filesize.
Start-Sleep -Seconds 1
$port.ReadExisting() # Get confirmation message from programmer
Write-Host "`nFlash Read Done."
#Close Serial Port
$port.Close()


# -- Write File or Verify File Dump --
if ($cartAction -eq "R") {
	[System.IO.File]::WriteAllBytes($filePath, $cartDump)
	Write-Host "ROM File Written to $filePath"
}
elseif (Compare-Object $cartROM $cartDump -SyncWindow 0) { 
	Write-Host "Errors Found. Try again."
}
else {
	Write-Host "Cartridge Verified. No Errors Found."
}
Read-Host -Prompt "Press Enter to Quit"
Exit