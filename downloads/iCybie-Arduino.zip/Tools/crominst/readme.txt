Original CROMINST cartridge files. Used to make a Super I-Cybie.

DO NOT USE IN A 2005 MODEL I-CYBIE MODEL 88013. It will brick it.