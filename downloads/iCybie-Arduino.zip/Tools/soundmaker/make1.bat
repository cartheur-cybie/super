rem - convert all WAVs to ADP
adpcm66 SAMPLE\*.wav
