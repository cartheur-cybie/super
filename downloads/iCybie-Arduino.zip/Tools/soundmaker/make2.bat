REM Merge ADP
icaud newcart.ic3 SAMPLE
splitic3 SAMPLE.ic3 SAMPLE-l.bin SAMPLE-h.bin
