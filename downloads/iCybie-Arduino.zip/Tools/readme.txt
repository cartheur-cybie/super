I-Cybie Programming Tools
YICT folder includes personality / cartridge ROM files and tools to modify and flash them.

Most of the included files are copies of the original YICT / ZCybie software and tools.

Tools\YICT\00_CybieDump.PS1
Powershell script intended for use with Pilotgeek's Arduino based cartridge programmer.
Run it to flash a cartridge. 

Brand new, never before seen Duke Nukem personality is included. It's bitchin, and i-Cybie agrees.
Tools\YICT\DukeNukem202-h.bin
Tools\YICT\DukeNukem202-l.bin
